/**




*/

#include <bits/stdc++.h>


using namespace std;

int main(){

    float suma =0, var;

    while(cin>>var){
        suma+=var;
    }
    cout<<suma;


return 0;
}
